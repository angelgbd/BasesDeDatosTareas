package com.example.empresajpa;

public enum Estatus {
    ACTIVO,
    INACTIVO
}
