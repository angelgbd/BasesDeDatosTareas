package com.tienda;

import DAOS.ProductoDAO;
import com.mycompany.jpatienda.Productos;
import java.util.List;


public class JPATienda {

    public static void main(String[] args) {
        ProductoDAO productoDAO = new ProductoDAO();

       
        System.out.println("--- INSERTANDO PRODUCTOS ---");
        productoDAO.insertar(new Productos("Laptop Gamer", 1500.50));
        productoDAO.insertar(new Productos("Mouse Inalámbrico", 25.00));
        productoDAO.insertar(new Productos("Teclado Mecánico", 120.75));
        System.out.println("Productos insertados.\n");

        
        System.out.println("--- LISTA INICIAL DE PRODUCTOS ---");
        List<Productos> productos = productoDAO.listar();
        productos.forEach(System.out::println);
        System.out.println();

        
        System.out.println("--- ACTUALIZANDO PRODUCTO ID=1 ---");
        Productos productoAModificar = productoDAO.buscar(1L); // Buscamos el producto con ID 1
        if (productoAModificar != null) {
            productoAModificar.setPrecio(1450.00); // Cambiamos el precio
            productoDAO.actualizar(productoAModificar);
            System.out.println("Producto actualizado.\n");

            
            System.out.println("--- LISTA DESPUÉS DE ACTUALIZAR ---");
            productoDAO.listar().forEach(System.out::println);
            System.out.println();
        } else {
            System.out.println("No se encontró el producto con ID 1.\n");
        }

     
        System.out.println("--- ELIMINANDO PRODUCTO ID=2 ---");
        productoDAO.eliminar(2L); // Eliminamos el producto con ID 2
        System.out.println("Producto eliminado.\n");

       
        System.out.println("--- LISTA FINAL DE PRODUCTOS ---");
        productoDAO.listar().forEach(System.out::println);
        System.out.println();

        
        productoDAO.cerrar();
    }
}