package DAOS;

import com.mycompany.jpatienda.Productos;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.List;

public class ProductoDAO {

    private final EntityManagerFactory emf;

    public ProductoDAO() {
        // Crea el EntityManagerFactory usando el nombre de la unidad de persistencia.
        this.emf = Persistence.createEntityManagerFactory("TiendaPU");
    }

    // --- Métodos CRUD ---

    public void insertar(Productos p) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(p); // Guarda el objeto en la base de datos.
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void actualizar(Productos p) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(p); // Actualiza el objeto si ya existe.
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void eliminar(Long id) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Productos p = em.find(Productos.class, id);
            if (p != null) {
                em.remove(p); // Elimina el objeto de la base de datos.
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public Productos buscar(Long id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Productos.class, id); // Busca un producto por su clave primaria.
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Productos> listar() {
        EntityManager em = emf.createEntityManager();
        try {
            // JPQL (Java Persistence Query Language) para obtener todos los productos.
            return em.createQuery("SELECT p FROM Producto p", Productos.class).getResultList();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    // Método para cerrar el factory cuando la aplicación termine.
    public void cerrar() {
        if (emf != null) {
            emf.close();
        }
    }
}
